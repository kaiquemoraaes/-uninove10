/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhojavaingresso;
public class Vip extends Principal {

	private float valorAdicinal;

	public Vip(float precoPrincipal, float valorAdicinal) {
		super(precoPrincipal);
		this.valorAdicinal = valorAdicinal;
	}

	public float imprimirValorVip() {
		return this.imprimirValor() + valorAdicinal;
	}

}
