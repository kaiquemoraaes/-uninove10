/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhojavaingresso;


public class CamaroteInferior extends Vip {

	private String localizacao;

	public CamaroteInferior(float precoPrincipal, float valorAdicinal) {
		super(precoPrincipal, valorAdicinal);
	}

	public void acessarLocalizacao(String localizacao) {
		this.localizacao = localizacao;
	}

	public String imprimirLocalizacao() {
		return this.localizacao;
	}
	
	public float valorPrincipalInferior() {
		return this.imprimirValor();
	}	

  

}
