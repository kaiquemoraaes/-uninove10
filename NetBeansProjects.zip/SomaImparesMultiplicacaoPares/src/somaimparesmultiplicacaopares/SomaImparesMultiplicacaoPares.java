package somaimparesmultiplicacaopares;

public class SomaImparesMultiplicacaoPares {

    public static void main(String[] args) {
        int soma = 0;
        long produto = 1;
        for (int i = 1; i < 30; i += 2) {
            soma += i;
            produto *= (i + 1);
            System.out.println("---\n" + i);
        }
        System.out.println("A SOMA DOS NÚMEROS ÍMPARES DE 1 A 30 SÃO:\n" + soma);
        System.out.println("A MULTIPLICAÇÃO DOS NÚMEROS PARES DE 1 A 30 SÃO:\n" + produto);
    }
}
